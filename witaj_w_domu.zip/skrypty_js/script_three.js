let lp = 1;

function addfilm() {
    document.getElementById('addMovie').addEventListener('click', function() {
      const title = document.getElementById('titleInput').value;
      const director = document.getElementById('directorInput').value;
      const year = document.getElementById('yearInput').value;

      const tabletwo = document.createElement("tr");
      const indexs = document.createElement("td");
      indexs.innerText = lp++;
      tabletwo.appendChild(indexs);

      const titles = document.createElement("td");
      titles.innerText = title;
      tabletwo.appendChild(titles);

      const directorek = document.createElement("td");
      directorek.innerText = director;
      tabletwo.appendChild(directorek);

      const yearCell = document.createElement("td");
      yearCell.innerText = year;
      tabletwo.appendChild(yearCell);

      document.getElementById('moviesBody').appendChild(tabletwo);

      document.getElementById('titleInput').value = '';
      document.getElementById('directorInput').value = '';
      document.getElementById('yearInput').value = '';
    })};