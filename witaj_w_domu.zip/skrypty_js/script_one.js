function kalkulator() {
    let val1 = parseFloat(document.getElementById('val1').value);
    let operator = document.getElementById('operator').value;

    let wynik;
    switch(operator) {
        case 'EUR':
            wynik = val1 * 0.23;
            break;
        case 'USD':
            wynik = val1 * 0.25;
            break;
        default:
            wynik = "Zły operator";
    }

    document.getElementById('wynik').innerText = val1 + " PLN " + " to " + wynik + " " + operator;
}