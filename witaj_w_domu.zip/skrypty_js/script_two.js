function add_element() {
    var lista = document.getElementById("demo1");
    var element = document.createElement("li");
    element.textContent = prompt("Podaj technologie programistyczną: ");
    lista.appendChild(element);
}

function remove_element() {
    var lista = document.getElementById("demo1");
    if (lista.children.length > 0) {
        lista.removeChild(lista.lastChild);
    }
}

function remove_all_list() {
    var lista = document.getElementById("demo1");
    lista.innerHTML = "";
}